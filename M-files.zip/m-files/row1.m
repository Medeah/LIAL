function y = row1(A,i,j)
%row1(A,i,j) interchanges rows i and j of the matrix A
y = A;
y(i,:) =  A(j,:);
y(j,:) = A(i,:);
